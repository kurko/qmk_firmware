# Kyria's Keymap adapted to Spanish MacOS (WIP)



The default keymap contains 7 layers which allows it to include all keys found on spanish Apple keyboard plus media keys.
Hardware features of the Kyria such as OLEDs and underglow are also supported.

The five different layers are the following:
1. Base layer (QWERTY, Colemak-DH or Dvorak)
2. Navigation layer
3. Symbols/Numbers layer
4. Function layer
5. Adjust layer
6. Numpad layer
7. Mouse layer

Look into keymap.c to view mappings
