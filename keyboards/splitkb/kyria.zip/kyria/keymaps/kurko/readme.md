# Kyria's Default Keymap

![Kyria split keyboard](https://i.ibb.co/RQZx2dY/default-kyria2.jpg)

Custom keymap for the [kyria
keyboard](https://blog.splitkb.com/blog/introducing-the-kyria). It is intended
to be used with an English (US, US intl.) keyboard layout.

